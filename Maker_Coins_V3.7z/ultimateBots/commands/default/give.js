const { SlashCommandBuilder, EmbedBuilder ,TextInputStyle,TextInputBuilder ,ModalBuilder,PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
module.exports ={
      ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('give')
    .setDescription('اعطاء لشخص رصيد')
,
    async execute(interaction, client) {
        const modal = new ModalBuilder()
        .setCustomId('give')
     .setTitle('Give coins');
        const Bot_token = new TextInputBuilder()
        .setCustomId('user')
        .setLabel("اي دي المستخدم")
          .setStyle(TextInputStyle.Short)
          .setMinLength(10)
          .setMaxLength(20)
        const Bot_prefix = new TextInputBuilder()
        .setCustomId('coins')
        .setLabel("عدد الكوينس")
          .setStyle(TextInputStyle.Short)
          .setMinLength(1)
          .setMaxLength(3)
          const firstActionRow = new ActionRowBuilder().addComponents(Bot_token);
          const firstActionRow2 = new ActionRowBuilder().addComponents(Bot_prefix);
          modal.addComponents(firstActionRow,firstActionRow2)
          await interaction.showModal(modal)
}
}
