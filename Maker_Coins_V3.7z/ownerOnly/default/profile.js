const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const {createCanvas, loadImage} = require('canvas')
const usersdata = new Database(`/database/usersdata/usersdata`)
module.exports ={
    ownersOnly:false,
    data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('رؤ ية بروفايلك او بروفايل شخص اخر')
    .addUserOption(Option => Option
        .setName(`user`)
        .setDescription(`الشخص`)
        .setRequired(false)),
    async execute(interaction) {
        const user = interaction.options.getUser(`user`) ?? interaction.user
        let userbalance = usersdata.get(`balance_${user.id}_${interaction.guild.id}`) ?? 0;
        let userbots = usersdata.get(`bots_${user.id}_${interaction.guild.id}`) ?? 0;
        let usersub = usersdata.get(`sub_${user.id}`);
        let userstatus = usersub ? "مشترك" : "غير مشترك";

        // إنشاء EmbedBuilder
        const embedBuilder = new EmbedBuilder()
          .setColor("#f6f6f6")
          .setTitle("معلومات الحساب")
     .setDescription(`**:moneybag: Balance: \`${userbalance}\` عملة. \n\n :star: Subscription: \`${userstatus}\`.  \n\n :robot: Bots: \`${userbots}\` بوت. **`);

        // إرسال الرد بشكل جذاب للمتفاعل فقط
        interaction.reply({ embeds: [embedBuilder], ephemeral: true });
    }
}