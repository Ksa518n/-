const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const usersdata = new Database(`/database/usersdata/usersdata`);




module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('transfer')
        .setDescription('Transfer coins to user')
        .addUserOption(option => option
            .setName('user')
            .setDescription('الشخص المراد تحويل الرصيد اليه')
            .setRequired(true))
        .addIntegerOption(option => option
            .setName('quantity')
            .setDescription('الكمية')
            .setRequired(true)),
    async execute(interaction, client) {
        try {
            const user = interaction.options.getUser('user');
            const quantity = interaction.options.getInteger('quantity');
            const authorBalance = usersdata.get(`balance_${interaction.user.id}_${interaction.guild.id}`) || 0;

            if (authorBalance < quantity) {
                await interaction.reply({
                    content: 'عذراً، ليس لديك رصيد كافي للقيام بهذه العملية.',
                    ephemeral: true
                });
                return;
            }

            const cancelEmbed = new EmbedBuilder()
           .setColor('#ff0000')
           .setDescription(`هل انت متاكد انك تريد تحويل ${quantity} من رصيدك الي ${user}؟`);



            const confirmationEmbed = new EmbedBuilder()
                .setColor('#f6f6f6')
                .setTitle(`تأكيد عملية التحويل`)
                .setDescription(`هل انت متاكد انك تريد تحويل ${quantity} من رصيدك الي ${user}؟`);

            const actionRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('confirm')
                        .setLabel('تأكيد')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('cancel')
                        .setLabel('إلغاء')
                        .setStyle(ButtonStyle.Danger)
                );

            await interaction.reply({
                embeds: [confirmationEmbed],
                components: [actionRow]
            });

            const collectorFilter = i => i.user.id === interaction.user.id && i.isButton();
            const collector = interaction.channel.createMessageComponentCollector({
                filter: collectorFilter,
                time: 30000, // 30 seconds
                max: 1
            });

            collector.on('collect', async buttonInteraction => {
                const { customId } = buttonInteraction;

                if (customId === 'confirm') {
                    const userBalance = usersdata.get(`balance_${user.id}_${interaction.guild.id}`) || 0;
                    const newAuthorBalance = authorBalance - quantity;
                    const newUserBalance = userBalance + quantity;

                    await usersdata.set(`balance_${user.id}_${interaction.guild.id}`, newUserBalance);
                    await usersdata.set(`balance_${interaction.user.id}_${interaction.guild.id}`, newAuthorBalance);

                    const successEmbed = new EmbedBuilder()
                        .setColor('#2bd664')
                        .setTitle('تمت عملية التحويل بنجاح')
                        .setDescription(`لقد قمت بتحويل ${quantity} من رصيدك إلى ${user}.`);


                    await interaction.editReply({
                        embeds: [successEmbed],
                        components: [] 
                    });
                } else if (customId === 'cancel') {
                    await interaction.editReply({
                        content: 'تم إلغاء عملية التحويل',
                        embeds: [cancelEmbed],
                        components: [] 
                    });
                }
            });

            collector.on('end', async () => {
                await interaction.editReply({
                    components: [] 
                });
            });
        } catch (error) {
            console.error(error);
            await interaction.reply('حدث خطأ أثناء معالجة طلبك.');
        }
    }
};
