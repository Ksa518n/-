const { SlashCommandBuilder, EmbedBuilder,Client , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle, Embed } = require("discord.js");
const { Database } = require("st.db")
const tokens = new Database("/tokens/tokens")
module.exports =  {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('bot-time')
    .setDescription('معرفة الوقت المتبقي')
    ,
    async execute(interaction) {

       const subsearch = await tokens.get(`probot`)
       const serversearch = subsearch.find(su => su.clientId == interaction.client.user.id)
       if(!serversearch) {
        return interaction.reply({content:`**لم يتم العثور على اشتراك بهذا الايدي**`,ephemeral:true})
       }
       const {timeleft} = serversearch

       return interaction.reply({content : `**الوقت المتبقي هو ${Math.floor(timeleft / (24 * 60 * 60))}يوما و ${Math.floor((timeleft % (24 * 60 * 60)) / (60 * 60))} ساعة و ${Math.floor((timeleft % (60 * 60)) / (60))} دقيقة و ${Math.floor((timeleft % 60))} ثانية .**`})
    }
}